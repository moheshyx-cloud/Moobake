/* ============================================================
   MOОBAKE CONFIGURATION
   Edit this section first. Do not add sensitive information here.
   ============================================================ */

const CONFIG = {
  currency: "kr",
  // Put the real bakery email here if you want mailto links to open.
  // Example: orderEmail: "hello@example.com"
  orderEmail: "",
  contactEmail: "",

  delivery: {
    fee: null, // Example: 50. Use null until you decide the real fee.
    zones: ["Add your delivery zones here"],
    times: ["Add delivery time slots here"],
    businessHours: "Add your business hours here"
  },

  pickup: {
    location: "", // Do NOT invent the address. Add the real pickup address here.
    times: ["Add pickup time slots here"],
    businessHours: "Add pickup hours here"
  },

  products: [
    {id:"choc-cake", name:"Chocolate Cake", category:"Cakes", price:120, emoji:"🍫", description:"Rich chocolate cake with a soft, homemade crumb.", allergens:"Wheat, eggs, milk."},
    {id:"vanilla-cake", name:"Vanilla Cake", category:"Cakes", price:110, emoji:"🍰", description:"Soft vanilla cake with a delicate sweet finish.", allergens:"Wheat, eggs, milk."},
    {id:"strawberry-cupcakes", name:"Strawberry Cupcakes", category:"Cupcakes", price:75, emoji:"🧁", description:"Fluffy cupcakes finished with strawberry-style frosting.", allergens:"Wheat, eggs, milk."},
    {id:"choc-cookies", name:"Chocolate Chip Cookies", category:"Cookies", price:55, emoji:"🍪", description:"Golden cookies packed with chocolate chips.", allergens:"Wheat, eggs, milk. May contain nuts."},
    {id:"biscoff-cheesecake", name:"Biscoff Cheesecake", category:"Cheesecakes", price:135, emoji:"🍮", description:"Creamy cheesecake with a spiced biscuit base.", allergens:"Wheat, milk, soy."},
    {id:"fudge-brownie", name:"Fudge Brownie", category:"Brownies", price:65, emoji:"🍫", description:"Dense, chocolatey and fudgy.", allergens:"Wheat, eggs, milk."}
  ]
};

/* ============================================================
   APP
   ============================================================ */
const $ = (selector) => document.querySelector(selector);
const cart = JSON.parse(localStorage.getItem("moobakeCart") || "[]");
let currentCategory = "All";

function money(value) {
  return `${Number(value).toFixed(0)} ${CONFIG.currency}`;
}

function saveCart() {
  localStorage.setItem("moobakeCart", JSON.stringify(cart));
}

function showToast(message) {
  const toast = $("#toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.remove("show"), 2600);
}

function categories() {
  return ["All", ...new Set(CONFIG.products.map(p => p.category))];
}

function renderCategories() {
  $("#categoryTabs").innerHTML = categories().map(cat =>
    `<button class="${cat === currentCategory ? "active" : ""}" data-category="${escapeHtml(cat)}">${escapeHtml(cat)}</button>`
  ).join("");
}

function renderProducts() {
  const products = currentCategory === "All"
    ? CONFIG.products
    : CONFIG.products.filter(p => p.category === currentCategory);

  $("#productGrid").innerHTML = products.map(p => `
    <article class="product-card reveal visible">
      <div class="product-image" aria-label="${escapeHtml(p.name)}">${p.emoji}</div>
      <div class="product-content">
        <h3>${escapeHtml(p.name)}</h3>
        <p>${escapeHtml(p.description)}</p>
        <p class="muted"><strong>Allergens:</strong> ${escapeHtml(p.allergens || "Ask MooBake.")}</p>
        <div class="product-meta">
          <span class="price">${money(p.price)}</span>
          <button class="small-btn" data-add="${p.id}">Add to cart</button>
        </div>
      </div>
    </article>
  `).join("");
}

function cartQuantity() {
  return cart.reduce((sum, item) => sum + item.qty, 0);
}

function cartSubtotal() {
  return cart.reduce((sum, item) => {
    const product = CONFIG.products.find(p => p.id === item.id);
    return sum + (product ? product.price * item.qty : 0);
  }, 0);
}

function renderCart() {
  $("#cartCount").textContent = cartQuantity();
  $("#cartSubtotal").textContent = money(cartSubtotal());

  if (!cart.length) {
    $("#cartItems").innerHTML = `<div class="empty">Your cart is empty.<br>Pick something sweet from the menu.</div>`;
    return;
  }

  $("#cartItems").innerHTML = cart.map(item => {
    const p = CONFIG.products.find(product => product.id === item.id);
    if (!p) return "";
    return `
      <div class="cart-item">
        <div class="cart-thumb">${p.emoji}</div>
        <div>
          <h4>${escapeHtml(p.name)}</h4>
          <small>${money(p.price)} each</small>
          <div class="qty">
            <button data-minus="${p.id}" aria-label="Decrease ${escapeHtml(p.name)}">−</button>
            <strong>${item.qty}</strong>
            <button data-plus="${p.id}" aria-label="Increase ${escapeHtml(p.name)}">+</button>
          </div>
        </div>
        <strong>${money(p.price * item.qty)}</strong>
      </div>`;
  }).join("");
}

function addToCart(id) {
  const item = cart.find(i => i.id === id);
  if (item) item.qty++;
  else cart.push({id, qty:1});
  saveCart();
  renderCart();
  showToast("Added to your cart.");
}

function changeQty(id, delta) {
  const item = cart.find(i => i.id === id);
  if (!item) return;
  item.qty += delta;
  if (item.qty <= 0) cart.splice(cart.indexOf(item), 1);
  saveCart();
  renderCart();
}

function openCart() {
  $("#cartDrawer").classList.add("open");
  $("#cartDrawer").setAttribute("aria-hidden","false");
}

function closeCart() {
  $("#cartDrawer").classList.remove("open");
  $("#cartDrawer").setAttribute("aria-hidden","true");
}

function openCheckout() {
  if (!cart.length) {
    showToast("Add at least one product first.");
    return;
  }
  closeCart();
  updateCheckoutPreview();
  $("#checkoutModal").classList.add("open");
  $("#checkoutModal").setAttribute("aria-hidden","false");
}

function closeCheckout() {
  $("#checkoutModal").classList.remove("open");
  $("#checkoutModal").setAttribute("aria-hidden","true");
}

function updateCheckoutPreview() {
  const deliveryFee = CONFIG.delivery.fee;
  const subtotal = cartSubtotal();
  const feeText = deliveryFee == null ? "Delivery fee: To be confirmed" : money(deliveryFee);
  $("#orderPreview").innerHTML = `
    <strong>Order summary</strong>
    ${cart.map(item => {
      const p = CONFIG.products.find(x => x.id === item.id);
      return p ? `<div><span>${escapeHtml(p.name)} × ${item.qty}</span><span>${money(p.price * item.qty)}</span></div>` : "";
    }).join("")}
    <hr>
    <div><strong>Subtotal</strong><strong>${money(subtotal)}</strong></div>
    <div><span>${feeText}</span><span>${deliveryFee == null ? "" : money(deliveryFee)}</span></div>
  `;
}

function updateMethodFields() {
  const method = $("#orderMethod").value;
  const pickup = method === "pickup";
  $("#deliveryFields").classList.toggle("hidden", pickup);
  $("#pickupFields").classList.toggle("hidden", !pickup);
  $("#deliveryAddress").required = !pickup;
  if (pickup) {
    $("#pickupLocationText").textContent = CONFIG.pickup.location
      ? `Pickup location: ${CONFIG.pickup.location}`
      : "Pickup address has not been added yet. Add it in script.js before publishing.";
  }
}

function orderText(data) {
  const lines = cart.map(item => {
    const p = CONFIG.products.find(x => x.id === item.id);
    return p ? `- ${p.name} x${item.qty}: ${money(p.price * item.qty)}` : "";
  }).filter(Boolean);

  return [
    "MooBake🍰 ORDER REQUEST",
    "",
    `Name: ${data.name}`,
    `Email: ${data.email}`,
    `Phone: ${data.phone}`,
    `Order type: ${data.method === "pickup" ? "Pickup — Gothenburg" : "Delivery"}`,
    `Date: ${data.date}`,
    `Time: ${data.time}`,
    data.method === "delivery" ? `Address: ${data.address}` : "Pickup location: Gothenburg, Sweden",
    "",
    "Items:",
    ...lines,
    "",
    `Subtotal: ${money(cartSubtotal())}`,
    CONFIG.delivery.fee == null ? "Delivery fee: To be confirmed" : `Delivery fee: ${money(CONFIG.delivery.fee)}`,
    `Notes: ${data.notes || "None"}`
  ].join("\n");
}

function submitOrder(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const data = Object.fromEntries(new FormData(form).entries());

  if (data.method === "pickup" && !$("#gothenburgConfirm").checked) {
    showToast("Please confirm that pickup is in Gothenburg.");
    return;
  }

  const text = orderText(data);
  const subject = encodeURIComponent(`MooBake order request — ${data.name}`);
  const body = encodeURIComponent(text);

  // Static-site behavior: if an email is configured, open the customer's email app.
  // Otherwise copy the request and show it on screen.
  if (CONFIG.orderEmail) {
    window.location.href = `mailto:${CONFIG.orderEmail}?subject=${subject}&body=${body}`;
  } else {
    navigator.clipboard?.writeText(text).catch(() => {});
  }

  form.reset();
  cart.length = 0;
  saveCart();
  renderCart();
  closeCheckout();

  $("#cartItems").innerHTML = `<div class="empty"><strong>Order request prepared.</strong><br>${CONFIG.orderEmail ? "Your email app should open so you can send it to MooBake." : "Your order details were copied when your browser allowed it. Add orderEmail in script.js to enable a direct email draft."}</div>`;
  openCart();
  showToast("Order request prepared.");
}

function submitCustom(event) {
  event.preventDefault();
  const data = Object.fromEntries(new FormData(event.currentTarget).entries());
  const text = [
    "MooBake🍰 CUSTOM CAKE REQUEST",
    "",
    `Name: ${data.name}`,
    `Email: ${data.email}`,
    `Phone: ${data.phone}`,
    `Preferred date: ${data.date}`,
    `Servings: ${data.servings || "Not specified"}`,
    `Flavor: ${data.flavor || "Not specified"}`,
    `Theme/colors: ${data.theme || "Not specified"}`,
    `Writing: ${data.writing || "None"}`,
    `Notes: ${data.notes || "None"}`
  ].join("\n");

  if (CONFIG.orderEmail) {
    window.location.href = `mailto:${CONFIG.orderEmail}?subject=${encodeURIComponent("MooBake custom cake request")}&body=${encodeURIComponent(text)}`;
  } else {
    navigator.clipboard?.writeText(text).catch(() => {});
  }

  event.currentTarget.reset();
  showToast("Custom cake request prepared.");
}

function submitContact(event) {
  event.preventDefault();
  const data = Object.fromEntries(new FormData(event.currentTarget).entries());
  const body = `Name: ${data.name}\nEmail: ${data.email}\n\n${data.message}`;
  if (CONFIG.contactEmail) {
    window.location.href = `mailto:${CONFIG.contactEmail}?subject=${encodeURIComponent("MooBake website message")}&body=${encodeURIComponent(body)}`;
  } else {
    navigator.clipboard?.writeText(body).catch(() => {});
    showToast("Message prepared. Add contactEmail in script.js to send it by email.");
  }
  event.currentTarget.reset();
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
  }[char]));
}

/* Navigation */
$("#menuToggle").addEventListener("click", () => {
  const nav = $("#mainNav");
  const open = nav.classList.toggle("open");
  $("#menuToggle").setAttribute("aria-expanded", String(open));
});
document.querySelectorAll("#mainNav a").forEach(a => a.addEventListener("click", () => $("#mainNav").classList.remove("open")));

/* Products and cart */
renderCategories();
renderProducts();
renderCart();
$("#year").textContent = new Date().getFullYear();

$("#categoryTabs").addEventListener("click", e => {
  const button = e.target.closest("[data-category]");
  if (!button) return;
  currentCategory = button.dataset.category;
  renderCategories();
  renderProducts();
});

$("#productGrid").addEventListener("click", e => {
  const button = e.target.closest("[data-add]");
  if (button) addToCart(button.dataset.add);
});

$("#cartItems").addEventListener("click", e => {
  const plus = e.target.closest("[data-plus]");
  const minus = e.target.closest("[data-minus]");
  if (plus) changeQty(plus.dataset.plus, 1);
  if (minus) changeQty(minus.dataset.minus, -1);
});

$("#openCart").addEventListener("click", openCart);
$("#closeCart").addEventListener("click", closeCart);
$("#checkoutBtn").addEventListener("click", openCheckout);
$("#closeCheckout").addEventListener("click", closeCheckout);
$("#orderMethod").addEventListener("change", updateMethodFields);
$("#checkoutForm").addEventListener("submit", submitOrder);
$("#customForm").addEventListener("submit", submitCustom);
$("#contactForm").addEventListener("submit", submitContact);

$("#cartDrawer").addEventListener("click", e => {
  if (e.target === $("#cartDrawer")) closeCart();
});
$("#checkoutModal").addEventListener("click", e => {
  if (e.target === $("#checkoutModal")) closeCheckout();
});

updateMethodFields();
updateCheckoutPreview();

/* Simple scroll reveal */
const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add("visible");
      observer.unobserve(entry.target);
    }
  });
}, {threshold:.12});
document.querySelectorAll(".reveal").forEach(el => observer.observe(el));
